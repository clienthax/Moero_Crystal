global.document = {};
global.$ = global.jQuery = function() {};
global.$.fn = {};

var WickedGrid = require('../../wickedgrid');

describe('WickedGrid', function() {

});