tf.test('Cells Merging: Rows Standard', function() {

});