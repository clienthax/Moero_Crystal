[![Stories in Ready](https://badge.waffle.io/spreadsheets/jquery.sheet.png?label=ready&title=Ready)](https://waffle.io/spreadsheets/WickedGrid)
WickedGrid
============

[![Join the chat at https://gitter.im/Spreadsheets/WickedGrid](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/Spreadsheets/WickedGrid?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

#faster than native spreadsheets?... coming soon :)

the ajax spreadsheet

[Demo](http://spreadsheets.github.io/WickedGrid)

[3.1 Documentation](http://visop-dev.com/doc/js3/index.html)

[![tip for next commit](http://prime4commit.com/projects/174.svg)](http://prime4commit.com/projects/174)
